<?php
	$SERVER_NAME="localhost";
	$USER_NAME="root";
	$PASSWORD="";
	$DB_NAME="educat";

	$conn = mysqli_connect($SERVER_NAME, $USER_NAME, $PASSWORD, $DB_NAME);
	// $SERVER_NAME="littlesouls.soulservices.com";
	// $USER_NAME="littlesoulssouls_admin";
	// $PASSWORD='=fBH&].UeN}}';
	// $DB_NAME="littlesoulssouls_educat";

	// $conn = mysqli_connect($SERVER_NAME, $USER_NAME, $PASSWORD, $DB_NAME);
	// Check connection
	// if (!$conn) {
	// die("Connection failed: " . mysqli_connect_error());
	// }
	// echo "Connected successfully";

 ?>